/*
 *
 *  Created by Optisol on Aug 2019.
 *  Copyright © 2019 Optisol Business Solutions pvt ltd. All rights reserved.
 *
 */

package com.obs.marveleditor.utils

class OptiOutputType {
    companion object {
        var TYPE_VIDEO = "video"
    }
}