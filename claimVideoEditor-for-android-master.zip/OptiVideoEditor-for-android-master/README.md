# OptiVideoEditor-for-Android

OptiVideoEditor - This is a professional video edit app, it's an easy & practical video editing app for expertise & beginners.This is an awesome video editor with free video trimmer. Slow & fast motion, video trimming, video merge and more features, to help you to make great video show in one minute!

![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-android/master/screenshots/home.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-android/master/screenshots/sticker.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-android/master/screenshots/audio.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-android/master/screenshots/video_merge.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-android/master/screenshots/playback.png)
![Image of Yaktocat](https://raw.githubusercontent.com/jaiobs/OptiVideoEditor-for-android/master/screenshots/text.png)



# Features

. Video trim

. Audio

. Video merge

. Slow and fast motion

. Text and image
